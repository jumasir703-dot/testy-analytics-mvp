import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { STANDARD_BAND_SETS } from "../src/utils/grading";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding Testy Analytics demo school...");

  const school = await prisma.school.create({
    data: {
      name: "Kebirigo Secondary School",
      code: "KEBRG-SEC",
      county: "Kisii",
      contactEmail: "info@kebirigosec.ac.ke",
    },
  });

  // ---- Subscription: KES 5,000/year, active for the next 365 days -----------
  const now = new Date();
  const oneYearFromNow = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);
  const subscription = await prisma.subscription.create({
    data: {
      schoolId: school.id,
      planName: "Standard Annual",
      amount: 5000,
      currency: "KES",
      status: "ACTIVE",
      startedAt: now,
      expiresAt: oneYearFromNow,
    },
  });
  await prisma.payment.create({
    data: {
      subscriptionId: subscription.id,
      amount: 5000,
      method: "MPESA",
      reference: "SEED0000001",
      extendsUntil: oneYearFromNow,
    },
  });

  // ---- Grading systems (one per curriculum, admin can add more/custom) -----
  const gradingSystems = await Promise.all([
    prisma.gradingSystem.create({
      data: {
        schoolId: school.id,
        name: "KCSE 8-4-4 Standard",
        curriculum: "EIGHT_FOUR_FOUR",
        isDefault: true,
        bands: { create: STANDARD_BAND_SETS.EIGHT_FOUR_FOUR },
      },
    }),
    prisma.gradingSystem.create({
      data: {
        schoolId: school.id,
        name: "CBC Performance Levels",
        curriculum: "CBC",
        bands: { create: STANDARD_BAND_SETS.CBC },
      },
    }),
    prisma.gradingSystem.create({
      data: {
        schoolId: school.id,
        name: "IGCSE Standard",
        curriculum: "IGCSE",
        bands: { create: STANDARD_BAND_SETS.IGCSE },
      },
    }),
  ]);
  const eightFourFour = gradingSystems[0];

  // ---- Academic year / term --------------------------------------------------
  const year = await prisma.academicYear.create({
    data: { schoolId: school.id, year: 2026, isCurrent: true },
  });
  const term = await prisma.term.create({
    data: { academicYearId: year.id, name: "Term 2", isCurrent: true },
  });

  // ---- Grade levels & streams -------------------------------------------------
  const form1 = await prisma.gradeLevel.create({
    data: { schoolId: school.id, name: "Form 1", order: 1, curriculum: "EIGHT_FOUR_FOUR" },
  });
  const streamEast = await prisma.stream.create({ data: { schoolId: school.id, gradeLevelId: form1.id, name: "East" } });

  // ---- Subjects ---------------------------------------------------------------
  const subjectDefs = [
    { name: "Mathematics", code: "MATH" },
    { name: "English", code: "ENG" },
    { name: "Kiswahili", code: "KIS" },
    { name: "Biology", code: "BIO" },
    { name: "Chemistry", code: "CHEM" },
  ];
  const subjects = await Promise.all(
    subjectDefs.map((s) => prisma.subject.create({ data: { schoolId: school.id, ...s } }))
  );
  await Promise.all(subjects.map((s) => prisma.classSubject.create({ data: { gradeLevelId: form1.id, subjectId: s.id } })));

  // ---- Admin user ---------------------------------------------------------------
  const passwordHash = await bcrypt.hash("Password123!", 10);
  await prisma.user.create({
    data: {
      schoolId: school.id,
      email: "admin@kebirigosec.ac.ke",
      passwordHash,
      role: "SCHOOL_ADMIN",
      fullName: "School Administrator",
    },
  });

  // ---- A teacher, made class teacher of Form 1 East -------------------------
  const teacherUser = await prisma.user.create({
    data: {
      schoolId: school.id,
      email: "teacher@kebirigosec.ac.ke",
      passwordHash,
      role: "CLASS_TEACHER",
      fullName: "Jane Mwangi",
      staffProfile: { create: { staffNumber: "T001" } },
    },
    include: { staffProfile: true },
  });
  await prisma.stream.update({ where: { id: streamEast.id }, data: { classTeacherId: teacherUser.staffProfile!.id } });
  await Promise.all(
    subjects.map((s) =>
      prisma.teacherSubject.create({ data: { staffId: teacherUser.staffProfile!.id, subjectId: s.id, streamId: streamEast.id } })
    )
  );

  // ---- Demo students ---------------------------------------------------------
  const studentNames = [
    ["ADM001", "Brian Otieno", "MALE"],
    ["ADM002", "Faith Nyaboke", "FEMALE"],
    ["ADM003", "Kevin Kiplagat", "MALE"],
    ["ADM004", "Grace Achieng", "FEMALE"],
    ["ADM005", "Dennis Mwikya", "MALE"],
  ] as const;

  const students = await Promise.all(
    studentNames.map(([admissionNo, fullName, gender]) =>
      prisma.student.create({ data: { schoolId: school.id, admissionNo, fullName, gender, streamId: streamEast.id } })
    )
  );

  // ---- An exam with per-subject default max scores ---------------------------
  const exam = await prisma.exam.create({
    data: {
      schoolId: school.id,
      academicYearId: year.id,
      termId: term.id,
      name: "Term 2 Mid-Term Exam",
      examType: "MID_TERM",
      gradingSystemId: eightFourFour.id,
      examDate: new Date("2026-05-15"),
      examSubjects: { create: subjects.map((s) => ({ subjectId: s.id, maxScore: 100 })) },
    },
  });

  // ---- Demo marks (randomized but deterministic-ish) --------------------------
  const rand = (min: number, max: number) => Math.round(min + Math.random() * (max - min));
  for (const student of students) {
    for (const subject of subjects) {
      const raw = rand(35, 95);
      const percentage = raw; // maxScore is 100 here
      const band = STANDARD_BAND_SETS.EIGHT_FOUR_FOUR.find((b) => percentage >= b.minPercentage && percentage <= b.maxPercentage)!;
      await prisma.result.create({
        data: {
          schoolId: school.id,
          studentId: student.id,
          examId: exam.id,
          subjectId: subject.id,
          rawScore: raw,
          maxScore: 100,
          percentage,
          gradeLabel: band.label,
          points: band.points,
          status: "APPROVED",
        },
      });
    }
  }

  console.log("Seed complete.");
  console.log("Login: admin@kebirigosec.ac.ke / Password123!  (SCHOOL_ADMIN)");
  console.log("Login: teacher@kebirigosec.ac.ke / Password123! (CLASS_TEACHER)");
  console.log(`Exam ID for testing analytics endpoints: ${exam.id}`);
  console.log(`Stream ID (Form 1 East): ${streamEast.id}`);
  console.log(`Subscription: KES 5,000/year, active until ${oneYearFromNow.toDateString()}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
