import "dotenv/config";
import express from "express";
import cors from "cors";
import { authRouter } from "./routes/auth.routes";
import { billingRouter } from "./routes/billing.routes";
import { studentsRouter } from "./routes/students.routes";
import { examsRouter, subjectsRouter } from "./routes/exams.routes";
import { resultsRouter } from "./routes/results.routes";
import { analyticsRouter } from "./routes/analytics.routes";
import { requireAuth, requireActiveSubscription } from "./middleware/auth.middleware";

const app = express();

app.use(cors());
app.use(express.json({ limit: "2mb" }));

app.get("/health", (_req, res) => res.json({ status: "ok", app: "Testy Analytics", time: new Date().toISOString() }));

app.use("/api/auth", authRouter);
// Billing is reachable while logged in even if the subscription has lapsed —
// a school needs to be able to see its bill and pay it while locked out.
app.use("/api/billing", billingRouter);

// Every other tenant route requires both a valid session AND an active
// subscription. This is the single choke point where a school's access
// "shuts down" the moment KES 5,000/year isn't paid.
app.use("/api/students", requireAuth, requireActiveSubscription, studentsRouter);
app.use("/api/exams", requireAuth, requireActiveSubscription, examsRouter);
app.use("/api/subjects", requireAuth, requireActiveSubscription, subjectsRouter);
app.use("/api/results", requireAuth, requireActiveSubscription, resultsRouter);
app.use("/api/analytics", requireAuth, requireActiveSubscription, analyticsRouter);

// Centralized error handler — catches thrown errors with a statusCode (see scopedSchoolId etc.)
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  res.status(err.statusCode ?? 500).json({ error: err.message ?? "Internal server error" });
});

const port = Number(process.env.PORT) || 4000;
app.listen(port, () => {
  console.log(`Testy Analytics API listening on http://localhost:${port}`);
});

