import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { Role } from "@prisma/client";
import { prisma } from "../lib/prisma";

export interface AuthUser {
  id: string;
  schoolId: string | null;
  role: Role;
  staffId?: string;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

/** Verifies the Bearer JWT and attaches `req.user`. All routes except /auth/login use this. */
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or malformed Authorization header" });
  }
  const token = header.slice("Bearer ".length);
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET as string) as AuthUser;
    req.user = payload;
    next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
}

/** Restricts a route to a set of roles, e.g. requireRole("SCHOOL_ADMIN", "PRINCIPAL"). */
export function requireRole(...roles: Role[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) return res.status(401).json({ error: "Not authenticated" });
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: "Insufficient permissions for this action" });
    }
    next();
  };
}

/**
 * Testy Analytics subscription gate.
 * ----------------------------------------------------------------------------
 * Runs after requireAuth on every tenant route. A school's access "shuts down"
 * automatically the instant its Subscription.expiresAt passes — this is
 * checked live on every request (not just by a nightly cron), so there's no
 * window where a lapsed school keeps working until some batch job catches up.
 *
 * SUPER_ADMIN bypasses this (the platform operator always needs access to
 * manage billing/subscriptions themselves).
 */
export async function requireActiveSubscription(req: Request, res: Response, next: NextFunction) {
  if (!req.user) return res.status(401).json({ error: "Not authenticated" });
  if (req.user.role === "SUPER_ADMIN") return next();

  const schoolId = req.user.schoolId;
  if (!schoolId) return res.status(400).json({ error: "User is not attached to a school" });

  const subscription = await prisma.subscription.findUnique({ where: { schoolId } });

  if (!subscription) {
    return res.status(402).json({
      error: "No active subscription for this school",
      code: "SUBSCRIPTION_MISSING",
    });
  }

  const now = new Date();
  const lapsed = subscription.expiresAt <= now;

  if (lapsed && subscription.status !== "EXPIRED") {
    // Lazily flip the status the first time we notice it's lapsed, so
    // dashboards/reports reflect reality without waiting on a cron sweep.
    await prisma.subscription.update({
      where: { schoolId },
      data: { status: "EXPIRED", lastCheckedAt: now },
    });
  }

  if (lapsed || subscription.status === "CANCELLED") {
    return res.status(402).json({
      error: "Subscription expired. Renew to restore access to Testy Analytics.",
      code: "SUBSCRIPTION_EXPIRED",
      expiredAt: subscription.expiresAt,
      renewUrl: "/api/billing/renew",
      amountDueKES: subscription.amount,
    });
  }

  next();
}


export function scopedSchoolId(req: Request): string {
  if (!req.user?.schoolId) {
    const err = new Error("User is not attached to a school") as Error & { statusCode?: number };
    err.statusCode = 400;
    throw err;
  }
  return req.user.schoolId;
}
