import { Router } from "express";
import { prisma } from "../lib/prisma";
import { scopedSchoolId } from "../middleware/auth.middleware";
import { mean, standardDeviation, rank, gradeDistribution, correlation } from "../utils/statistics";

export const analyticsRouter = Router();

/**
 * Subject performance for one exam: mean, std dev, grade distribution,
 * top/bottom performers. This is the core "how did Maths do in the Mid Term"
 * view teachers and HoDs look at first.
 */
analyticsRouter.get("/exam/:examId/subject/:subjectId", async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const { examId, subjectId } = req.params;

  const results = await prisma.result.findMany({
    where: { schoolId, examId, subjectId, rawScore: { not: null } },
    include: { student: { select: { id: true, fullName: true, admissionNo: true, gender: true } } },
  });

  if (results.length === 0) {
    return res.json({ count: 0, mean: 0, stdDev: 0, gradeDistribution: {}, topPerformers: [], weakestPerformers: [] });
  }

  const scores = results.map((r) => r.percentage ?? 0);
  const ranked = rank(results, (r) => r.percentage ?? 0);

  const genderBreakdown = {
    MALE: mean(results.filter((r) => r.student.gender === "MALE").map((r) => r.percentage ?? 0)),
    FEMALE: mean(results.filter((r) => r.student.gender === "FEMALE").map((r) => r.percentage ?? 0)),
  };

  res.json({
    count: results.length,
    mean: round2(mean(scores)),
    stdDev: round2(standardDeviation(scores)),
    highest: Math.max(...scores),
    lowest: Math.min(...scores),
    gradeDistribution: gradeDistribution(results.map((r) => r.gradeLabel ?? "N/A")),
    genderBreakdown: { male: round2(genderBreakdown.MALE), female: round2(genderBreakdown.FEMALE) },
    topPerformers: ranked
      .sort((a, b) => a.position - b.position)
      .slice(0, 5)
      .map((r) => ({ studentId: r.student.id, name: r.student.fullName, admissionNo: r.student.admissionNo, score: r.percentage, position: r.position })),
    weakestPerformers: ranked
      .sort((a, b) => b.position - a.position)
      .slice(0, 5)
      .map((r) => ({ studentId: r.student.id, name: r.student.fullName, admissionNo: r.student.admissionNo, score: r.percentage, position: r.position })),
  });
});

/**
 * Class/stream performance for one exam: mean grade, per-student overall
 * ranking (based on mean percentage across all subjects sat), and per-subject
 * means for a bar-chart view.
 */
analyticsRouter.get("/exam/:examId/class/:streamId", async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const { examId, streamId } = req.params;

  const results = await prisma.result.findMany({
    where: { schoolId, examId, student: { streamId }, rawScore: { not: null } },
    include: { student: { select: { id: true, fullName: true, admissionNo: true } }, subject: true },
  });

  // Group by student to compute each student's mean % across subjects.
  const byStudent = new Map<string, { name: string; admissionNo: string; scores: number[] }>();
  for (const r of results) {
    const entry = byStudent.get(r.studentId) ?? { name: r.student.fullName, admissionNo: r.student.admissionNo, scores: [] };
    entry.scores.push(r.percentage ?? 0);
    byStudent.set(r.studentId, entry);
  }
  const studentMeans = Array.from(byStudent.entries()).map(([studentId, v]) => ({
    studentId,
    name: v.name,
    admissionNo: v.admissionNo,
    meanScore: round2(mean(v.scores)),
  }));
  const rankedStudents = rank(studentMeans, (s) => s.meanScore).sort((a, b) => a.position - b.position);

  // Group by subject for a per-subject mean bar chart.
  const bySubject = new Map<string, { name: string; scores: number[] }>();
  for (const r of results) {
    const entry = bySubject.get(r.subjectId) ?? { name: r.subject.name, scores: [] };
    entry.scores.push(r.percentage ?? 0);
    bySubject.set(r.subjectId, entry);
  }
  const subjectMeans = Array.from(bySubject.entries()).map(([subjectId, v]) => ({
    subjectId,
    name: v.name,
    mean: round2(mean(v.scores)),
    stdDev: round2(standardDeviation(v.scores)),
  }));

  res.json({
    classMean: round2(mean(studentMeans.map((s) => s.meanScore))),
    studentCount: studentMeans.length,
    ranking: rankedStudents,
    subjectMeans: subjectMeans.sort((a, b) => b.mean - a.mean),
  });
});

/** A single student's score trend across all exams for one subject (or overall if subjectId omitted). */
analyticsRouter.get("/student/:studentId/trend", async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const { subjectId } = req.query as Record<string, string>;

  const results = await prisma.result.findMany({
    where: { schoolId, studentId: req.params.studentId, ...(subjectId ? { subjectId } : {}), rawScore: { not: null } },
    include: { exam: { select: { id: true, name: true, examDate: true } }, subject: { select: { id: true, name: true } } },
    orderBy: { exam: { examDate: "asc" } },
  });

  const points = results.map((r) => ({
    examId: r.exam.id,
    examName: r.exam.name,
    examDate: r.exam.examDate,
    subject: r.subject.name,
    score: r.percentage,
    grade: r.gradeLabel,
  }));

  // Improvement = latest score - first score, per subject.
  const bySubject = new Map<string, number[]>();
  for (const p of points) {
    const arr = bySubject.get(p.subject) ?? [];
    arr.push(p.score ?? 0);
    bySubject.set(p.subject, arr);
  }
  const improvement = Array.from(bySubject.entries()).map(([subject, scores]) => ({
    subject,
    firstScore: scores[0],
    latestScore: scores[scores.length - 1],
    delta: round2(scores[scores.length - 1] - scores[0]),
  }));

  res.json({ points, improvement });
});

/** School-wide overview: mean per grade level, gender gap, top subjects, weakest subjects. */
analyticsRouter.get("/school/overview", async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const { examId } = req.query as Record<string, string>;
  if (!examId) return res.status(400).json({ error: "examId query param is required" });

  const results = await prisma.result.findMany({
    where: { schoolId, examId, rawScore: { not: null } },
    include: { subject: true, student: { select: { gender: true, streamId: true } } },
  });

  const bySubject = new Map<string, number[]>();
  for (const r of results) {
    const arr = bySubject.get(r.subject.name) ?? [];
    arr.push(r.percentage ?? 0);
    bySubject.set(r.subject.name, arr);
  }
  const subjectStats = Array.from(bySubject.entries())
    .map(([name, scores]) => ({ subject: name, mean: round2(mean(scores)), count: scores.length }))
    .sort((a, b) => b.mean - a.mean);

  const maleScores = results.filter((r) => r.student.gender === "MALE").map((r) => r.percentage ?? 0);
  const femaleScores = results.filter((r) => r.student.gender === "FEMALE").map((r) => r.percentage ?? 0);

  res.json({
    schoolMean: round2(mean(results.map((r) => r.percentage ?? 0))),
    totalMarksRecorded: results.length,
    strongestSubjects: subjectStats.slice(0, 5),
    weakestSubjects: [...subjectStats].sort((a, b) => a.mean - b.mean).slice(0, 5),
    genderGap: { male: round2(mean(maleScores)), female: round2(mean(femaleScores)) },
  });
});

/** Subject vs subject correlation for one exam — e.g. does Maths performance track Physics? */
analyticsRouter.get("/exam/:examId/subject-comparison", async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const { examId } = req.params;
  const { subjectA, subjectB } = req.query as Record<string, string>;
  if (!subjectA || !subjectB) return res.status(400).json({ error: "subjectA and subjectB query params are required" });

  const [resultsA, resultsB] = await Promise.all([
    prisma.result.findMany({ where: { schoolId, examId, subjectId: subjectA, rawScore: { not: null } } }),
    prisma.result.findMany({ where: { schoolId, examId, subjectId: subjectB, rawScore: { not: null } } }),
  ]);

  const scoresA_byStudent = new Map(resultsA.map((r) => [r.studentId, r.percentage ?? 0]));
  const pairedA: number[] = [];
  const pairedB: number[] = [];
  for (const r of resultsB) {
    if (scoresA_byStudent.has(r.studentId)) {
      pairedA.push(scoresA_byStudent.get(r.studentId)!);
      pairedB.push(r.percentage ?? 0);
    }
  }

  res.json({
    studentsCompared: pairedA.length,
    correlation: correlation(pairedA, pairedB),
    meanSubjectA: round2(mean(pairedA)),
    meanSubjectB: round2(mean(pairedB)),
  });
});

function round2(n: number) {
  return Math.round(n * 100) / 100;
}
