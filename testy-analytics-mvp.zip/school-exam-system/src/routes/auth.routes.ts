import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { prisma } from "../lib/prisma";

export const authRouter = Router();

const loginSchema = z.object({
  identifier: z.string().min(3), // email or phone
  password: z.string().min(6),
});

authRouter.post("/login", async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid input", details: parsed.error.flatten() });
  }
  const { identifier, password } = parsed.data;

  const user = await prisma.user.findFirst({
    where: {
      OR: [{ email: identifier }, { phone: identifier }],
      isActive: true,
    },
    include: { staffProfile: true },
  });

  // Deliberately generic error message — don't leak whether the identifier exists.
  if (!user) return res.status(401).json({ error: "Invalid credentials" });

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) return res.status(401).json({ error: "Invalid credentials" });

  const tokenPayload = {
    id: user.id,
    schoolId: user.schoolId,
    role: user.role,
    staffId: user.staffProfile?.id,
  };

  const token = jwt.sign(tokenPayload, process.env.JWT_SECRET as string, {
    expiresIn: (process.env.JWT_EXPIRES_IN ?? "8h") as jwt.SignOptions["expiresIn"],
  });

  await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });

  res.json({
    token,
    user: {
      id: user.id,
      fullName: user.fullName,
      role: user.role,
      schoolId: user.schoolId,
    },
  });
});
