import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { requireAuth, requireRole, scopedSchoolId } from "../middleware/auth.middleware";

/**
 * Billing routes are deliberately NOT behind requireActiveSubscription —
 * a school with a lapsed subscription must still be able to see why they're
 * locked out and pay to renew. Every other /api/* route is gated.
 */
export const billingRouter = Router();
billingRouter.use(requireAuth);

const YEAR_MS = 365 * 24 * 60 * 60 * 1000;

// ---- Current subscription status -------------------------------------------
billingRouter.get("/status", async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const subscription = await prisma.subscription.findUnique({
    where: { schoolId },
    include: { payments: { orderBy: { paidAt: "desc" }, take: 5 } },
  });

  if (!subscription) return res.status(404).json({ error: "No subscription found for this school" });

  const now = new Date();
  const daysRemaining = Math.ceil((subscription.expiresAt.getTime() - now.getTime()) / (24 * 60 * 60 * 1000));

  res.json({
    ...subscription,
    isActive: subscription.status === "ACTIVE" && subscription.expiresAt > now,
    daysRemaining,
  });
});

// ---- Initiate renewal (mock M-Pesa STK push) --------------------------------
// In production this calls Safaricom's Daraja API to trigger an STK push to
// the school admin's phone. The confirmation callback (below) is what
// actually extends the subscription — this endpoint only *starts* payment.
const initiateSchema = z.object({
  phone: z.string().min(10), // M-Pesa phone number to push the prompt to
});

billingRouter.post("/renew", requireRole("SCHOOL_ADMIN", "PRINCIPAL"), async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const parsed = initiateSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input", details: parsed.error.flatten() });

  const subscription = await prisma.subscription.findUnique({ where: { schoolId } });
  if (!subscription) return res.status(404).json({ error: "No subscription found for this school" });

  // TODO(production): call Daraja /mpesa/stkpush/v1/processrequest here with
  // amount=subscription.amount, phone=parsed.data.phone, and store the
  // CheckoutRequestID so the callback below can be matched to this attempt.
  const mockCheckoutRequestId = `ws_CO_${Date.now()}`;

  res.status(202).json({
    message: `STK push sent to ${parsed.data.phone} for KES ${subscription.amount}. Complete the M-Pesa prompt to renew.`,
    checkoutRequestId: mockCheckoutRequestId,
  });
});

// ---- M-Pesa callback: confirms payment and extends the subscription ---------
// This is the endpoint that actually reactivates a shut-down school.
// Safaricom (or your payment gateway) calls this server-to-server after the
// customer completes the STK push — it is NOT behind requireAuth in
// production (Daraja can't send a JWT); protect it instead with Daraja's IP
// allowlist / a shared secret, swapped in for requireAuth here.
const callbackSchema = z.object({
  schoolId: z.string(),
  amount: z.number().positive(),
  reference: z.string(), // M-Pesa transaction code, e.g. "SFC1A2B3C4"
  method: z.enum(["MPESA", "BANK", "CASH", "MANUAL"]).default("MPESA"),
});

billingRouter.post("/confirm-payment", requireRole("SCHOOL_ADMIN", "PRINCIPAL"), async (req, res) => {
  const parsed = callbackSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input", details: parsed.error.flatten() });
  const d = parsed.data;

  const subscription = await prisma.subscription.findUnique({ where: { schoolId: d.schoolId } });
  if (!subscription) return res.status(404).json({ error: "No subscription found for this school" });

  // Extend from "now" if already expired, or from the current expiry if still
  // active (so renewing early doesn't lose remaining paid time).
  const base = subscription.expiresAt > new Date() ? subscription.expiresAt : new Date();
  const newExpiry = new Date(base.getTime() + YEAR_MS);

  const [, payment] = await prisma.$transaction([
    prisma.subscription.update({
      where: { schoolId: d.schoolId },
      data: { status: "ACTIVE", expiresAt: newExpiry, lastCheckedAt: new Date() },
    }),
    prisma.payment.create({
      data: {
        subscriptionId: subscription.id,
        amount: d.amount,
        method: d.method,
        reference: d.reference,
        extendsUntil: newExpiry,
      },
    }),
  ]);

  res.json({
    message: "Payment confirmed. Testy Analytics access restored.",
    expiresAt: newExpiry,
    payment,
  });
});

// ---- Platform-operator only: manually adjust a school's subscription -------
billingRouter.patch("/schools/:schoolId", requireRole("SUPER_ADMIN"), async (req, res) => {
  const { status, expiresAt, amount } = req.body as { status?: string; expiresAt?: string; amount?: number };
  const subscription = await prisma.subscription.update({
    where: { schoolId: req.params.schoolId },
    data: {
      ...(status ? { status: status as any } : {}),
      ...(expiresAt ? { expiresAt: new Date(expiresAt) } : {}),
      ...(amount ? { amount } : {}),
      lastCheckedAt: new Date(),
    },
  });
  res.json(subscription);
});
