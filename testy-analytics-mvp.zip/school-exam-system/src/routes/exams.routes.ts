import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { requireRole, scopedSchoolId } from "../middleware/auth.middleware";

export const examsRouter = Router();

examsRouter.get("/", async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const { termId } = req.query as Record<string, string>;
  const exams = await prisma.exam.findMany({
    where: { schoolId, ...(termId ? { termId } : {}) },
    include: { examSubjects: { include: { subject: true } }, gradingSystem: true, term: true },
    orderBy: { examDate: "desc" },
  });
  res.json(exams);
});

examsRouter.get("/:id", async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const exam = await prisma.exam.findFirst({
    where: { id: req.params.id, schoolId },
    include: { examSubjects: { include: { subject: true } }, gradingSystem: { include: { bands: true } } },
  });
  if (!exam) return res.status(404).json({ error: "Exam not found" });
  res.json(exam);
});

const createExamSchema = z.object({
  name: z.string().min(2),
  examType: z.enum(["OPENER", "MID_TERM", "END_TERM", "MOCK", "NATIONAL", "CAT", "CUSTOM"]),
  academicYearId: z.string(),
  termId: z.string(),
  gradingSystemId: z.string(),
  weighting: z.number().min(0).max(10).optional(),
  examDate: z.string().datetime().optional(),
  // Optional per-subject max score overrides: [{ subjectId, maxScore }]
  subjects: z
    .array(z.object({ subjectId: z.string(), maxScore: z.number().positive().optional() }))
    .optional(),
});

examsRouter.post("/", requireRole("SCHOOL_ADMIN", "PRINCIPAL"), async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const parsed = createExamSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input", details: parsed.error.flatten() });
  const d = parsed.data;

  const exam = await prisma.exam.create({
    data: {
      schoolId,
      name: d.name,
      examType: d.examType,
      academicYearId: d.academicYearId,
      termId: d.termId,
      gradingSystemId: d.gradingSystemId,
      weighting: d.weighting ?? 1.0,
      examDate: d.examDate ? new Date(d.examDate) : undefined,
      examSubjects: d.subjects
        ? {
            create: d.subjects.map((s) => ({ subjectId: s.subjectId, maxScore: s.maxScore ?? 100 })),
          }
        : undefined,
    },
    include: { examSubjects: true },
  });

  res.status(201).json(exam);
});

examsRouter.patch("/:id/publish", requireRole("SCHOOL_ADMIN", "PRINCIPAL"), async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const exam = await prisma.exam.findFirst({ where: { id: req.params.id, schoolId } });
  if (!exam) return res.status(404).json({ error: "Exam not found" });
  const updated = await prisma.exam.update({ where: { id: exam.id }, data: { isPublished: true } });
  res.json(updated);
});

// ---- Subjects --------------------------------------------------------------
export const subjectsRouter = Router();

subjectsRouter.get("/", async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const subjects = await prisma.subject.findMany({ where: { schoolId }, orderBy: { name: "asc" } });
  res.json(subjects);
});

const createSubjectSchema = z.object({
  name: z.string().min(2),
  code: z.string().min(2),
  isCore: z.boolean().optional(),
  defaultMaxScore: z.number().positive().optional(),
});

subjectsRouter.post("/", requireRole("SCHOOL_ADMIN", "PRINCIPAL"), async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const parsed = createSubjectSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input", details: parsed.error.flatten() });
  const subject = await prisma.subject.create({
    data: { schoolId, ...parsed.data, code: parsed.data.code.toUpperCase() },
  });
  res.status(201).json(subject);
});
