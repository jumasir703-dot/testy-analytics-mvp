import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { requireRole, scopedSchoolId } from "../middleware/auth.middleware";
import { gradeRawScore } from "../utils/grading";

export const resultsRouter = Router();

// ---- List results (filterable — used by both mark-entry grid & analytics) --
resultsRouter.get("/", async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const { examId, subjectId, streamId } = req.query as Record<string, string>;

  const results = await prisma.result.findMany({
    where: {
      schoolId,
      ...(examId ? { examId } : {}),
      ...(subjectId ? { subjectId } : {}),
      ...(streamId ? { student: { streamId } } : {}),
    },
    include: { student: { select: { id: true, fullName: true, admissionNo: true, streamId: true } } },
    orderBy: { student: { fullName: "asc" } },
  });

  res.json(results);
});

resultsRouter.get("/student/:studentId", async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const results = await prisma.result.findMany({
    where: { schoolId, studentId: req.params.studentId },
    include: { subject: true, exam: { include: { term: true } } },
    orderBy: { exam: { examDate: "asc" } },
  });
  res.json(results);
});

// ---- Helper: resolve maxScore + grading system for a given exam/subject ----
async function resolveExamContext(examId: string, subjectId: string, schoolId: string) {
  const exam = await prisma.exam.findFirst({
    where: { id: examId, schoolId },
    include: { examSubjects: { where: { subjectId } } },
  });
  if (!exam) throw Object.assign(new Error("Exam not found"), { statusCode: 404 });

  const override = exam.examSubjects[0];
  let maxScore = override?.maxScore;
  if (!maxScore) {
    const subject = await prisma.subject.findFirst({ where: { id: subjectId, schoolId } });
    if (!subject) throw Object.assign(new Error("Subject not found"), { statusCode: 404 });
    maxScore = subject.defaultMaxScore;
  }
  return { maxScore, gradingSystemId: exam.gradingSystemId };
}

// ---- Single mark entry (create or update) -----------------------------------
const markEntrySchema = z.object({
  studentId: z.string(),
  examId: z.string(),
  subjectId: z.string(),
  rawScore: z.number().min(0).nullable(), // null => ABSENT
  status: z.enum(["DRAFT", "SUBMITTED", "APPROVED", "ABSENT", "EXEMPTED"]).optional(),
});

resultsRouter.post("/", requireRole("TEACHER", "CLASS_TEACHER", "SCHOOL_ADMIN", "PRINCIPAL"), async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const parsed = markEntrySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input", details: parsed.error.flatten() });
  const d = parsed.data;

  try {
    const result = await upsertResult(schoolId, req.user!.id, d);
    res.status(200).json(result);
  } catch (e: any) {
    res.status(e.statusCode ?? 500).json({ error: e.message ?? "Failed to save mark" });
  }
});

// ---- Bulk mark entry (array payload — used by the spreadsheet-style grid UI)
const bulkEntrySchema = z.object({
  examId: z.string(),
  subjectId: z.string(),
  marks: z.array(z.object({ studentId: z.string(), rawScore: z.number().min(0).nullable() })),
});

resultsRouter.post("/bulk", requireRole("TEACHER", "CLASS_TEACHER", "SCHOOL_ADMIN", "PRINCIPAL"), async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const parsed = bulkEntrySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input", details: parsed.error.flatten() });
  const { examId, subjectId, marks } = parsed.data;

  let context;
  try {
    context = await resolveExamContext(examId, subjectId, schoolId);
  } catch (e: any) {
    return res.status(e.statusCode ?? 500).json({ error: e.message });
  }

  const outcomes: Array<{ studentId: string; status: "ok" | "error"; message?: string }> = [];

  for (const m of marks) {
    if (m.rawScore !== null && m.rawScore > context.maxScore) {
      outcomes.push({
        studentId: m.studentId,
        status: "error",
        message: `Score ${m.rawScore} exceeds max score ${context.maxScore}`,
      });
      continue;
    }
    try {
      await upsertResult(schoolId, req.user!.id, {
        studentId: m.studentId,
        examId,
        subjectId,
        rawScore: m.rawScore,
      });
      outcomes.push({ studentId: m.studentId, status: "ok" });
    } catch (e: any) {
      outcomes.push({ studentId: m.studentId, status: "error", message: e.message });
    }
  }

  res.json({
    total: marks.length,
    succeeded: outcomes.filter((o) => o.status === "ok").length,
    failed: outcomes.filter((o) => o.status === "error").length,
    details: outcomes,
  });
});

// ---- Shared upsert logic: validates, grades, writes, and audit-logs --------
async function upsertResult(
  schoolId: string,
  userId: string,
  input: { studentId: string; examId: string; subjectId: string; rawScore: number | null; status?: any }
) {
  const { maxScore, gradingSystemId } = await resolveExamContext(input.examId, input.subjectId, schoolId);

  if (input.rawScore !== null && input.rawScore > maxScore) {
    const err = new Error(`Score ${input.rawScore} exceeds max score ${maxScore} for this subject/exam`);
    (err as any).statusCode = 400;
    throw err;
  }

  let percentage: number | null = null;
  let gradeLabel: string | null = null;
  let points: number | null = null;

  if (input.rawScore !== null) {
    const graded = await gradeRawScore(gradingSystemId, input.rawScore, maxScore);
    percentage = graded.percentage;
    gradeLabel = graded.gradeLabel;
    points = graded.points;
  }

  const existing = await prisma.result.findUnique({
    where: {
      studentId_examId_subjectId: {
        studentId: input.studentId,
        examId: input.examId,
        subjectId: input.subjectId,
      },
    },
  });

  const data = {
    schoolId,
    studentId: input.studentId,
    examId: input.examId,
    subjectId: input.subjectId,
    rawScore: input.rawScore,
    maxScore,
    percentage,
    gradeLabel,
    points,
    status: input.status ?? (input.rawScore === null ? "ABSENT" : "DRAFT"),
    enteredById: userId,
  };

  const result = existing
    ? await prisma.result.update({ where: { id: existing.id }, data })
    : await prisma.result.create({ data });

  await prisma.auditLog.create({
    data: {
      schoolId,
      userId,
      action: existing ? "RESULT_UPDATE" : "RESULT_CREATE",
      entity: "Result",
      entityId: result.id,
      before: existing ? (existing as any) : undefined,
      after: result as any,
    },
  });

  return result;
}
