import { Router } from "express";
import { z } from "zod";
import multer from "multer";
import ExcelJS from "exceljs";
import { prisma } from "../lib/prisma";
import { requireRole, scopedSchoolId } from "../middleware/auth.middleware";

export const studentsRouter = Router();

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

// ---- List students (paginated, filterable) ------------------------------
studentsRouter.get("/", async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const { streamId, search, page = "1", pageSize = "25" } = req.query as Record<string, string>;

  const where = {
    schoolId,
    isActive: true,
    ...(streamId ? { streamId } : {}),
    ...(search
      ? {
          OR: [
            { fullName: { contains: search, mode: "insensitive" as const } },
            { admissionNo: { contains: search, mode: "insensitive" as const } },
          ],
        }
      : {}),
  };

  const take = Math.min(Number(pageSize) || 25, 100);
  const skip = (Math.max(Number(page) || 1, 1) - 1) * take;

  const [students, total] = await Promise.all([
    prisma.student.findMany({
      where,
      include: { stream: { include: { gradeLevel: true } } },
      orderBy: { fullName: "asc" },
      take,
      skip,
    }),
    prisma.student.count({ where }),
  ]);

  res.json({ data: students, pagination: { total, page: Number(page), pageSize: take } });
});

// ---- Get one student ------------------------------------------------------
studentsRouter.get("/:id", async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const student = await prisma.student.findFirst({
    where: { id: req.params.id, schoolId },
    include: { stream: { include: { gradeLevel: true } }, guardians: { include: { parent: { include: { user: true } } } } },
  });
  if (!student) return res.status(404).json({ error: "Student not found" });
  res.json(student);
});

// ---- Create a single student -----------------------------------------------
const createStudentSchema = z.object({
  admissionNo: z.string().min(1),
  fullName: z.string().min(2),
  gender: z.enum(["MALE", "FEMALE", "OTHER"]),
  streamId: z.string().min(1),
  dateOfBirth: z.string().datetime().optional(),
  hasDisability: z.boolean().optional(),
  disabilityNote: z.string().optional(),
});

studentsRouter.post("/", requireRole("SCHOOL_ADMIN", "PRINCIPAL", "CLASS_TEACHER"), async (req, res) => {
  const schoolId = scopedSchoolId(req);
  const parsed = createStudentSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input", details: parsed.error.flatten() });

  const existing = await prisma.student.findFirst({
    where: { schoolId, admissionNo: parsed.data.admissionNo },
  });
  if (existing) return res.status(409).json({ error: "Admission number already exists for this school" });

  const student = await prisma.student.create({
    data: {
      schoolId,
      admissionNo: parsed.data.admissionNo,
      fullName: parsed.data.fullName,
      gender: parsed.data.gender,
      streamId: parsed.data.streamId,
      dateOfBirth: parsed.data.dateOfBirth ? new Date(parsed.data.dateOfBirth) : undefined,
      hasDisability: parsed.data.hasDisability ?? false,
      disabilityNote: parsed.data.disabilityNote,
    },
  });

  await prisma.auditLog.create({
    data: { schoolId, userId: req.user!.id, action: "STUDENT_CREATE", entity: "Student", entityId: student.id, after: student as any },
  });

  res.status(201).json(student);
});

// ---- Bulk import via Excel/CSV --------------------------------------------
// Expected columns (header row required): admissionNo, fullName, gender, streamName, dateOfBirth (optional)
studentsRouter.post(
  "/bulk-import",
  requireRole("SCHOOL_ADMIN", "PRINCIPAL"),
  upload.single("file"),
  async (req, res) => {
    const schoolId = scopedSchoolId(req);
    if (!req.file) return res.status(400).json({ error: "No file uploaded (field name must be 'file')" });

    const workbook = new ExcelJS.Workbook();
    try {
      if (req.file.originalname.endsWith(".csv")) {
        await workbook.csv.read(bufferToStream(req.file.buffer));
      } else {
        await workbook.xlsx.load(req.file.buffer);
      }
    } catch (e) {
      return res.status(400).json({ error: "Could not parse file. Ensure it is a valid .xlsx or .csv." });
    }

    const sheet = workbook.worksheets[0];
    if (!sheet) return res.status(400).json({ error: "Uploaded file has no worksheet" });

    const headerRow = sheet.getRow(1).values as (string | undefined)[];
    const colIndex = (name: string) =>
      headerRow.findIndex((h) => h?.toString().trim().toLowerCase() === name.toLowerCase());

    const idx = {
      admissionNo: colIndex("admissionNo"),
      fullName: colIndex("fullName"),
      gender: colIndex("gender"),
      streamName: colIndex("streamName"),
      dateOfBirth: colIndex("dateOfBirth"),
    };

    if (idx.admissionNo === -1 || idx.fullName === -1 || idx.gender === -1 || idx.streamName === -1) {
      return res.status(400).json({
        error: "Missing required columns. Expected: admissionNo, fullName, gender, streamName (dateOfBirth optional)",
      });
    }

    // Pre-load streams for name -> id lookup (scoped to this school).
    const streams = await prisma.stream.findMany({ where: { schoolId }, include: { gradeLevel: true } });
    const streamByName = new Map(streams.map((s: (typeof streams)[number]) => [`${s.gradeLevel.name} ${s.name}`.toLowerCase(), s.id]));

    const results: Array<{ row: number; status: "created" | "skipped" | "error"; message?: string }> = [];
    const rowsToCreate: any[] = [];

    sheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return; // header
      const admissionNo = row.getCell(idx.admissionNo).text?.trim();
      const fullName = row.getCell(idx.fullName).text?.trim();
      const genderRaw = row.getCell(idx.gender).text?.trim().toUpperCase();
      const streamName = row.getCell(idx.streamName).text?.trim();

      if (!admissionNo || !fullName) {
        results.push({ row: rowNumber, status: "skipped", message: "Missing admissionNo or fullName" });
        return;
      }
      if (!["MALE", "FEMALE", "OTHER"].includes(genderRaw ?? "")) {
        results.push({ row: rowNumber, status: "error", message: `Invalid gender '${genderRaw}'` });
        return;
      }
      const streamId = streamByName.get((streamName ?? "").toLowerCase());
      if (!streamId) {
        results.push({ row: rowNumber, status: "error", message: `Unknown stream '${streamName}'` });
        return;
      }
      rowsToCreate.push({ admissionNo, fullName, gender: genderRaw, streamId, schoolId, __row: rowNumber });
    });

    // Insert sequentially so we can report per-row duplicate conflicts clearly.
    for (const row of rowsToCreate) {
      const exists = await prisma.student.findFirst({ where: { schoolId, admissionNo: row.admissionNo } });
      if (exists) {
        results.push({ row: row.__row, status: "skipped", message: "Admission number already exists" });
        continue;
      }
      await prisma.student.create({
        data: {
          schoolId,
          admissionNo: row.admissionNo,
          fullName: row.fullName,
          gender: row.gender,
          streamId: row.streamId,
        },
      });
      results.push({ row: row.__row, status: "created" });
    }

    await prisma.auditLog.create({
      data: {
        schoolId,
        userId: req.user!.id,
        action: "STUDENT_BULK_IMPORT",
        entity: "Student",
        entityId: "bulk",
        after: { summary: results } as any,
      },
    });

    res.json({
      totalRows: rowsToCreate.length,
      created: results.filter((r) => r.status === "created").length,
      skipped: results.filter((r) => r.status === "skipped").length,
      errors: results.filter((r) => r.status === "error").length,
      details: results,
    });
  }
);

function bufferToStream(buffer: Buffer) {
  const { Readable } = require("stream");
  return Readable.from(Uint8Array.from(buffer));
}
