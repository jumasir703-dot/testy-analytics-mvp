import { prisma } from "../lib/prisma";

/**
 * Grading Engine
 * ----------------------------------------------------------------------------
 * Curriculum-agnostic: given a percentage score and a GradingSystem's bands,
 * returns the matching grade label, points, and remark. This is what lets the
 * same codebase serve 8-4-4, CBC, IGCSE, or any school-defined scale without
 * special-casing anywhere else in the app — the "curriculum" only matters at
 * the point where an admin configures GradeBands.
 */

export interface GradeResult {
  gradeLabel: string;
  points: number;
  remark: string | null;
}

/** In-process cache of grading systems (bands rarely change; avoids a DB hit per mark). */
const bandCache = new Map<string, { fetchedAt: number; bands: Array<{
  minPercentage: number; maxPercentage: number; label: string; points: number; remark: string | null;
}> }>();

const CACHE_TTL_MS = 5 * 60 * 1000;

async function getBands(gradingSystemId: string): Promise<Array<{
  minPercentage: number; maxPercentage: number; label: string; points: number; remark: string | null;
}>> {
  const cached = bandCache.get(gradingSystemId);
  if (cached && Date.now() - cached.fetchedAt < CACHE_TTL_MS) {
    return cached.bands;
  }
  const bands = await prisma.gradeBand.findMany({
    where: { gradingSystemId },
    orderBy: { minPercentage: "desc" },
  });
  bandCache.set(gradingSystemId, { fetchedAt: Date.now(), bands });
  return bands;
}

/** Call after editing GradeBands via the admin UI so stale grades aren't served. */
export function invalidateGradingCache(gradingSystemId: string) {
  bandCache.delete(gradingSystemId);
}

/**
 * Resolve a percentage score against a grading system's bands.
 * Bands are checked highest-first and matched inclusively [min, max].
 * Throws if no band covers the score — this is intentional: a gap in grade
 * bands is a configuration error that should surface loudly, not silently
 * produce an ungraded result.
 */
export async function gradePercentage(
  gradingSystemId: string,
  percentage: number
): Promise<GradeResult> {
  const bands = await getBands(gradingSystemId);
  const band = bands.find((b) => percentage >= b.minPercentage && percentage <= b.maxPercentage);
  if (!band) {
    throw new Error(
      `No grade band covers ${percentage}% in grading system ${gradingSystemId}. Check band configuration for gaps.`
    );
  }
  return { gradeLabel: band.label, points: band.points, remark: band.remark };
}

/** Convenience: grade a raw score directly given a max score. */
export async function gradeRawScore(
  gradingSystemId: string,
  rawScore: number,
  maxScore: number
): Promise<GradeResult & { percentage: number }> {
  if (maxScore <= 0) throw new Error("maxScore must be greater than 0");
  const percentage = (rawScore / maxScore) * 100;
  const grade = await gradePercentage(gradingSystemId, percentage);
  return { ...grade, percentage: Math.round(percentage * 100) / 100 };
}

/**
 * Seed helpers: standard band sets for common curricula. Schools can start
 * from these and customize freely (this is exactly why bands live in the DB,
 * not in code).
 */
export const STANDARD_BAND_SETS = {
  EIGHT_FOUR_FOUR: [
    { minPercentage: 80, maxPercentage: 100, label: "A", points: 12, remark: "Excellent" },
    { minPercentage: 75, maxPercentage: 79.99, label: "A-", points: 11, remark: "Very Good" },
    { minPercentage: 70, maxPercentage: 74.99, label: "B+", points: 10, remark: "Good" },
    { minPercentage: 65, maxPercentage: 69.99, label: "B", points: 9, remark: "Good" },
    { minPercentage: 60, maxPercentage: 64.99, label: "B-", points: 8, remark: "Fair" },
    { minPercentage: 55, maxPercentage: 59.99, label: "C+", points: 7, remark: "Fair" },
    { minPercentage: 50, maxPercentage: 54.99, label: "C", points: 6, remark: "Average" },
    { minPercentage: 45, maxPercentage: 49.99, label: "C-", points: 5, remark: "Below Average" },
    { minPercentage: 40, maxPercentage: 44.99, label: "D+", points: 4, remark: "Weak" },
    { minPercentage: 35, maxPercentage: 39.99, label: "D", points: 3, remark: "Weak" },
    { minPercentage: 30, maxPercentage: 34.99, label: "D-", points: 2, remark: "Very Weak" },
    { minPercentage: 0, maxPercentage: 29.99, label: "E", points: 1, remark: "Very Weak" },
  ],
  CBC: [
    { minPercentage: 75, maxPercentage: 100, label: "EE", points: 4, remark: "Exceeding Expectation" },
    { minPercentage: 50, maxPercentage: 74.99, label: "ME", points: 3, remark: "Meeting Expectation" },
    { minPercentage: 30, maxPercentage: 49.99, label: "AE", points: 2, remark: "Approaching Expectation" },
    { minPercentage: 0, maxPercentage: 29.99, label: "BE", points: 1, remark: "Below Expectation" },
  ],
  IGCSE: [
    { minPercentage: 90, maxPercentage: 100, label: "A*", points: 9, remark: "Outstanding" },
    { minPercentage: 80, maxPercentage: 89.99, label: "A", points: 8, remark: "Excellent" },
    { minPercentage: 70, maxPercentage: 79.99, label: "B", points: 7, remark: "Very Good" },
    { minPercentage: 60, maxPercentage: 69.99, label: "C", points: 6, remark: "Good" },
    { minPercentage: 50, maxPercentage: 59.99, label: "D", points: 5, remark: "Satisfactory" },
    { minPercentage: 40, maxPercentage: 49.99, label: "E", points: 4, remark: "Pass" },
    { minPercentage: 30, maxPercentage: 39.99, label: "F", points: 3, remark: "Weak Pass" },
    { minPercentage: 20, maxPercentage: 29.99, label: "G", points: 2, remark: "Weak" },
    { minPercentage: 0, maxPercentage: 19.99, label: "U", points: 0, remark: "Ungraded" },
  ],
};
