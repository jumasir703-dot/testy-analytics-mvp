/**
 * Pure statistics helpers used by the analytics engine.
 * Kept dependency-free and framework-agnostic so they're trivially unit-testable.
 */

export function mean(values: number[]): number {
  if (values.length === 0) return 0;
  return values.reduce((sum, v) => sum + v, 0) / values.length;
}

export function standardDeviation(values: number[]): number {
  if (values.length < 2) return 0;
  const m = mean(values);
  const variance = values.reduce((sum, v) => sum + (v - m) ** 2, 0) / (values.length - 1);
  return Math.sqrt(variance);
}

/** Assigns 1-based rank with standard "competition ranking" (ties share a rank, next rank skips). */
export function rank<T>(items: T[], scoreOf: (item: T) => number): Array<T & { position: number }> {
  const sorted = [...items].sort((a, b) => scoreOf(b) - scoreOf(a));
  const result: Array<T & { position: number }> = [];
  let lastScore: number | null = null;
  let lastPosition = 0;
  sorted.forEach((item, idx) => {
    const score = scoreOf(item);
    if (lastScore === null || score < lastScore) {
      lastPosition = idx + 1;
      lastScore = score;
    }
    result.push({ ...item, position: lastPosition });
  });
  return result;
}

export function gradeDistribution(labels: string[]): Record<string, number> {
  return labels.reduce((acc, label) => {
    acc[label] = (acc[label] ?? 0) + 1;
    return acc;
  }, {} as Record<string, number>);
}

/** Simple Pearson correlation coefficient — used for subject vs subject comparison. */
export function correlation(a: number[], b: number[]): number | null {
  if (a.length !== b.length || a.length < 2) return null;
  const ma = mean(a);
  const mb = mean(b);
  let num = 0, da = 0, db = 0;
  for (let i = 0; i < a.length; i++) {
    num += (a[i] - ma) * (b[i] - mb);
    da += (a[i] - ma) ** 2;
    db += (b[i] - mb) ** 2;
  }
  const denom = Math.sqrt(da * db);
  return denom === 0 ? null : num / denom;
}
